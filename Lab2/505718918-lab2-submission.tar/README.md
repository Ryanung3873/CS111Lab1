# 505718918

# You Spin Me Round Robin

This is a Round Robin scheduling program for multiple processes with various arrival times and burst time that performs context switches based on quantum length.

## Building

```shell
make
```

## Running

cmd for running TODO
```shell
./rr processes.txt 3
```

results TODO
```shell
Average wait time: 11.80
Average response time: 4.2
```

## Cleaning up

```shell
make clean
```