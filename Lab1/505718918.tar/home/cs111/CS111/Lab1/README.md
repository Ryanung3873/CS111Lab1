## UID: 123456789

## Pipe Up

One sentence description

## Building

Explain briefly how to build your program

## Running

Show an example run of your program, using at least two additional arguments, and what to expect

## Cleaning up

Explain briefly how to clean up all binary files
